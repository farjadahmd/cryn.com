# Climate Resilience Youth Network (CRYN) — Vite + React Starter

## Quick start (for beginners)
1. Unzip the project.
2. Install dependencies:
   ```
   npm install
   ```
3. Run the development server:
   ```
   npm run dev
   ```
4. Open the address Vite prints (usually http://localhost:5173).

## Included features
- React + Vite starter
- TailwindCSS (config included)
- Framer Motion for simple animations
- Modular components under `src/components`
- Example `api/create-checkout-session.js` for Vercel (Stripe demo)
- Netlify forms-ready contact form and `_redirects` for Netlify
- `package.json` scripts ready for development/build

## Vercel Stripe serverless function (demo)
File: `api/create-checkout-session.js`
- This is a serverless function for Vercel that creates a Stripe Checkout session.
- **Do not** commit your secret keys to Git. Use Vercel Project Settings -> Environment Variables.

### Set the env var on Vercel:
- `STRIPE_SECRET_KEY` = your Stripe secret key

### Test cards
Use card number `4242 4242 4242 4242` with any future expiry and any CVC for test mode.

## Netlify forms
- The contact form has `data-netlify="true"` and `name="contact"`.
- Deploy on Netlify and form submissions will appear in Netlify dashboard.
- `_redirects` file included to show a success redirect after form submission.

## Deploying
- Vercel (recommended for serverless): connect your GitHub repo, set build command `npm run build`, output `dist`.
- Netlify: connect repo, build command `npm run build`, publish `dist`.

## Notes
- This is a demo starter. Replace placeholder images and text with your brand assets.
- For Stripe production, enable HTTPS, verify webhooks, and handle server-side order records.

