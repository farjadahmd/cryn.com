export const projects = [
  { id:1, title: 'Urban Heat Resilience Labs', summary:'Rapid pilots to test cooling solutions.', tags:['pilot','community','research'], img:'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?w=1400&q=80&auto=format&fit=crop' },
  { id:2, title: 'Coastal Flood Early Warnings', summary:'Low-cost sensors & SMS warnings.', tags:['tech','coastal'], img:'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1400&q=80&auto=format&fit=crop' },
  { id:3, title: 'Youth Climate Storytelling', summary:'Train young creators to advocate.', tags:['education','media'], img:'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=1400&q=80&auto=format&fit=crop' }
]

export const resources = [
  { id:1, title:'Community Cooling Guide (PDF)', type:'pdf', tags:['community','guide'] },
  { id:2, title:'Rapid Sensor Build (Tutorial)', type:'article', tags:['tech','open-hardware'] },
  { id:3, title:'Case Study: Lahore Heat Action Plan', type:'report', tags:['research'] },
  { id:4, title:'Funding Primer for NGOs', type:'guide', tags:['funding'] }
]

export const events = [
  { id:1, title:'Urban Cooling Pilot Launch', date:'2025-10-04', time:'10:00', timezone:'Asia/Karachi', location:'Lahore, Pakistan', description:'Launch event for the pilot with partners.' },
  { id:2, title:'Sensor Workshop for Students', date:'2025-11-12', time:'14:00', timezone:'Asia/Karachi', location:'Community Center', description:'Hands-on sensor building for teens.' }
]
