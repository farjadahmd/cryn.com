import React from 'react'
import ProjectCard from './ProjectCard'
import { projects } from '../data'
export default function Projects(){
  return (
    <section>
      <h2 className="text-2xl font-bold">Featured projects</h2>
      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map(p => <ProjectCard key={p.id} p={p} />)}
      </div>
    </section>
  )
}
