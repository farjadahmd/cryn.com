import React from 'react'
export default function Footer({ setActive }){
  return (
    <footer className="bg-slate-900 text-white py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <div className="font-bold">Climate Resilience Youth Network</div>
          <div className="text-slate-300 text-sm mt-2">Community-led projects, open tools, and youth training to reduce climate risks.</div>
          <div className="mt-4 text-sm">
            <div>Instagram: <a href="https://www.instagram.com/climateresilienceyouthnetwork/?utm_source=ig_web_button_share_sheet" className="underline">@climateresilienceyouthnetwork</a></div>
            <div>Email: <a className="underline" href="mailto:climateryn@gmail.com">climateryn@gmail.com</a></div>
            <div>Phone: <a className="underline" href="tel:+923303344338">+92 330 3344338</a></div>
          </div>
        </div>
        <div>
          <div className="font-semibold">Quick links</div>
          <ul className="mt-2 text-sm space-y-1 text-slate-300">
            <li><button onClick={()=>setActive('projects')} className="hover:underline">Projects</button></li>
            <li><button onClick={()=>setActive('resources')} className="hover:underline">Resources</button></li>
            <li><button onClick={()=>setActive('events')} className="hover:underline">Events</button></li>
            <li><a href="#" className="hover:underline">Privacy</a></li>
          </ul>
        </div>
        <div>
          <div className="font-semibold">Subscribe</div>
          <p className="text-sm text-slate-300 mt-2">Get monthly updates on pilots, resources, and volunteering.</p>
          <form onSubmit={(e)=>{e.preventDefault(); alert('Subscribed — check your email')}} className="mt-3 flex gap-2">
            <input required placeholder="Your email" className="px-3 py-2 rounded w-full text-slate-900" />
            <button className="px-4 py-2 rounded bg-emerald-400">Join</button>
          </form>
        </div>
      </div>
      <div className="mt-6 border-t border-slate-800 pt-4 text-center text-slate-400 text-sm">© {new Date().getFullYear()} Climate Resilience Youth Network — All rights reserved</div>
    </footer>
  )
}
