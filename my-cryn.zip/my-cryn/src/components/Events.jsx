import React from 'react'
import { events } from '../data'
export default function Events(){
  function downloadICS(ev){
    const uid = `${ev.id}-${Date.now()}@cryn.local`;
    const ics = [
      'BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//CRYN//EN','BEGIN:VEVENT',
      `UID:${uid}`,
      `DTSTAMP:${formatDateICS(new Date())}`,
      `DTSTART:${formatDateICS(new Date(ev.date + 'T' + ev.time))}`,
      `SUMMARY:${ev.title}`,
      `DESCRIPTION:${ev.description}`,
      `LOCATION:${ev.location}`,'END:VEVENT','END:VCALENDAR'
    ].join('\r\n')
    const blob = new Blob([ics], { type: 'text/calendar' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = `${ev.title}.ics`; a.click(); URL.revokeObjectURL(url)
  }
  function formatDateICS(d){ if(!(d instanceof Date)) d = new Date(d); const YYYY=d.getFullYear(),MM=String(d.getMonth()+1).padStart(2,'0'),DD=String(d.getDate()).padStart(2,'0'),hh=String(d.getHours()).padStart(2,'0'),mm=String(d.getMinutes()).padStart(2,'0'),ss=String(d.getSeconds()).padStart(2,'0'); return `${YYYY}${MM}${DD}T${hh}${mm}${ss}` }
  return (
    <section>
      <h2 className="text-2xl font-bold">Events & Workshops</h2>
      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
        {events.map(ev => (
          <div key={ev.id} className="p-4 rounded-lg bg-white border shadow-sm">
            <div className="flex items-start justify-between">
              <div>
                <div className="font-semibold text-lg">{ev.title}</div>
                <div className="text-sm text-slate-500">{ev.date} • {ev.time} ({ev.timezone})</div>
                <div className="text-sm text-slate-500">{ev.location}</div>
              </div>
              <div className="flex flex-col gap-2">
                <button onClick={() => downloadICS(ev)} className="px-3 py-2 rounded bg-slate-900 text-white text-sm">Add to calendar</button>
                <a href="#" className="px-3 py-2 rounded border text-sm">Register</a>
              </div>
            </div>
            <div className="text-slate-700 mt-3">{ev.description}</div>
          </div>
        ))}
      </div>
    </section>
  )
}
