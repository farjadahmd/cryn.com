import React from 'react'
import AnimatedGlobe from './AnimatedGlobe'
export default function Hero({ setActive }){
  return (
    <section className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
      <div className="lg:col-span-2">
        <h1 className="text-4xl sm:text-5xl font-extrabold">Empowering young people to build climate resilience — locally, globally.</h1>
        <p className="mt-4 text-lg text-slate-700">We design community-first projects, build open tools, and train youth to respond to heat, floods, and climate shocks.</p>
        <div className="mt-6 flex gap-3">
          <button onClick={() => setActive('getinvolved')} className="px-5 py-3 rounded-lg bg-slate-900 text-white font-semibold shadow">Get involved</button>
          <a href="#projects" className="px-5 py-3 rounded-lg border border-slate-300 text-slate-800">Explore projects</a>
        </div>
      </div>
      <div className="relative w-full rounded-2xl shadow-xl overflow-hidden">
        <div className="w-full h-72 bg-gradient-to-br from-sky-600 to-emerald-500 flex items-center justify-center text-white">
          <AnimatedGlobe />
        </div>
      </div>
    </section>
  )
}
