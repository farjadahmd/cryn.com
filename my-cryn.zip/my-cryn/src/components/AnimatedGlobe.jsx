import React from 'react'
import { motion } from 'framer-motion'
export default function AnimatedGlobe(){
  return (
    <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 30, ease: 'linear' }} className="w-48 h-48 flex items-center justify-center">
      <svg viewBox="0 0 200 200" className="w-48 h-48" >
        <defs>
          <linearGradient id="g1" x1="0" x2="1">
            <stop offset="0%" stopColor="#06b6d4" />
            <stop offset="100%" stopColor="#10b981" />
          </linearGradient>
        </defs>
        <circle cx="100" cy="100" r="80" fill="url(#g1)" opacity="0.95" />
        <path d="M60 90c10-18 36-28 56-18 10 5 22 19 20 30-3 18-26 26-40 24-14-2-42-12-36-36z" fill="#064e3b" opacity="0.9" />
      </svg>
    </motion.div>
  )
}
