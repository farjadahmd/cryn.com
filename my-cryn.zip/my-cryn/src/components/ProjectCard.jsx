import React from 'react'
export default function ProjectCard({ p }){
  return (
    <article className="bg-white rounded-lg shadow-sm border overflow-hidden">
      <div style={{ backgroundImage: `url(${p.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }} className="h-40 w-full" />
      <div className="p-4">
        <div className="font-semibold">{p.title}</div>
        <div className="text-sm text-slate-600 mt-2">{p.summary}</div>
        <div className="mt-4 flex items-center justify-between">
          <div className="text-xs text-slate-500">{p.tags.join(' • ')}</div>
          <a href="#" className="text-sm px-3 py-1 rounded bg-emerald-600 text-white">Learn</a>
        </div>
      </div>
    </article>
  )
}
