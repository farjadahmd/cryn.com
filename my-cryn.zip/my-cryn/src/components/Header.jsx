import React from 'react'
export default function Header({ active, setActive }){
  const nav = [['home','Home'],['projects','Projects'],['resources','Resources'],['events','Events'],['getinvolved','Get Involved'],['about','About']]
  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-white/60 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="rounded-full w-12 h-12 flex items-center justify-center bg-gradient-to-br from-emerald-600 to-sky-500 text-white font-bold shadow-lg">CR</div>
            <div>
              <div className="font-extrabold leading-tight">Climate Resilience Youth Network</div>
              <div className="text-xs text-slate-600">Community · Science · Action</div>
            </div>
          </div>
          <nav className="hidden md:flex gap-4 items-center">
            {nav.map(([k,label]) => (
              <button key={k} onClick={() => setActive(k)} className={`px-3 py-2 rounded-md text-sm font-medium ${active===k? 'bg-slate-900 text-white':'text-slate-700 hover:bg-slate-100'}`}>{label}</button>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <a className="text-sm px-3 py-2 rounded-md bg-emerald-600 text-white shadow" href="#">Donate</a>
            <a className="text-sm px-3 py-2 rounded-md border" href="#" onClick={() => setActive('getinvolved')}>Contact</a>
          </div>
        </div>
      </div>
    </header>
  )
}
