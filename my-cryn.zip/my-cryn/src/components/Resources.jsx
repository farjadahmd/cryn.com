import React, { useState } from 'react'
import { resources } from '../data'
export default function Resources(){
  const [query, setQuery] = useState('')
  const filtered = resources.filter(r => (r.title + r.type + r.tags.join(' ')).toLowerCase().includes(query.toLowerCase()))
  return (
    <section>
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Resources</h2>
          <p className="text-slate-600">Open-source guides, reports, and how-to tutorials.</p>
        </div>
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="search resources" className="px-3 py-2 border rounded" />
      </div>
      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(r => (
          <div key={r.id} className="p-4 rounded-lg bg-white border shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-semibold">{r.title}</div>
                <div className="text-xs text-slate-500 mt-1">{r.type} • {r.tags.join(', ')}</div>
              </div>
              <div className="flex flex-col gap-2">
                <a className="text-sm px-3 py-1 rounded bg-emerald-600 text-white" href="#">Open</a>
                <a className="text-sm px-3 py-1 rounded border" href="#">Download</a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
