import React, { useState } from 'react'
export default function GetInvolved(){
  const [form, setForm] = useState({ name:'', email:'', interests:[], message:'' })
  function submit(e){ e.preventDefault(); window.location.href = `mailto:climateryn@gmail.com?subject=${encodeURIComponent('[CRYN] Volunteer')}&body=${encodeURIComponent(JSON.stringify(form,null,2))}` }
  return (
    <section>
      <h2 className="text-2xl font-bold">Get involved</h2>
      <form name="contact" method="POST" data-netlify="true" netlify-honeypot="bot-field" onSubmit={submit} className="mt-6 bg-white p-6 rounded-lg shadow-sm border">
        <input type="hidden" name="form-name" value="contact" />
        <p className="hidden"><label>Don’t fill this out if you're human: <input name="bot-field" /></label></p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <input required value={form.name} onChange={e=>setForm({...form, name:e.target.value})} name="name" placeholder="Full name" className="px-3 py-2 border rounded w-full" />
          <input required value={form.email} onChange={e=>setForm({...form, email:e.target.value})} name="email" placeholder="Email" type="email" className="px-3 py-2 border rounded w-full" />
        </div>
        <textarea name="message" value={form.message} onChange={e=>setForm({...form, message:e.target.value})} placeholder="Tell us why you want to help" className="w-full px-3 py-2 border rounded h-28 mt-4" />
        <div className="mt-4 flex gap-3">
          <button type="submit" className="px-4 py-2 bg-emerald-600 text-white rounded">Send message</button>
        </div>
      </form>
    </section>
  )
}
