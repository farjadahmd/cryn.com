import React, { useState } from 'react'
import Header from './components/Header'
import Footer from './components/Footer'
import Hero from './components/Hero'
import Projects from './components/Projects'
import Resources from './components/Resources'
import Events from './components/Events'
import GetInvolved from './components/GetInvolved'

export default function App(){
  const [active, setActive] = useState('home')
  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-white to-green-50 text-slate-800">
      <Header active={active} setActive={setActive} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {active === 'home' && <><Hero setActive={setActive} /><Projects /></>}
        {active === 'projects' && <Projects />}
        {active === 'resources' && <Resources />}
        {active === 'events' && <Events />}
        {active === 'getinvolved' && <GetInvolved />}
        {active === 'about' && <section><h2 className="text-2xl font-bold">About</h2><p className="mt-2 text-slate-600">CRYN - youth-led climate resilience.</p></section>}
      </main>
      <Footer setActive={setActive} />
    </div>
  )
}
